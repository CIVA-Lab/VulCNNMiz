static void goodB2G()
{
    int data;
    CWE121_Stack_Based_Buffer_Overflow__CWE129_fscanf_67_structType myStruct;
    /* Initialize data */
    data = -1;
    /* POTENTIAL FLAW: Read data from the console using fscanf() */
    fscanf(stdin, "%d", &data);
    myStruct.structFirst = data;
    CWE121_Stack_Based_Buffer_Overflow__CWE129_fscanf_67b_goodB2GSink(myStruct);
}
