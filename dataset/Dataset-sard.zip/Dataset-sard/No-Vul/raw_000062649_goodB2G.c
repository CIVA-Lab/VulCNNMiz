static void goodB2G()
{
    int data;
    void (*funcPtr) (int) = CWE121_Stack_Based_Buffer_Overflow__CWE129_fscanf_65b_goodB2GSink;
    /* Initialize data */
    data = -1;
    /* POTENTIAL FLAW: Read data from the console using fscanf() */
    fscanf(stdin, "%d", &data);
    funcPtr(data);
}
